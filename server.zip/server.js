const express = require("express");
const app = express();
const db = require("./db");
app.use(express.json());
const PORT = 3000;
app.get("/", (req, res) => {
  res.send("Node.js Server Ready");
});
app.listen(PORT, () => {
  console.clear();
  console.log(`
==================================================
           BACKEND SERVER STARTED
==================================================

 Server URL
 http://localhost:${PORT}

 API Endpoint
 POST http://localhost:${PORT}/login

 Test Commandline
 curl -X POST http://localhost:3000/login ^
 -H "Content-Type: application/json" ^
 -d "{\\"username\\": \\"admin\\", \\"password\\": \\"1234\\"}"
 
 Test Browser
 URL http://localhost:${PORT}

 Test Postman
 Method : POST
 URK    : http://localhost:${PORT}/login
 Body (JSON)
        {
          "username":"admin",
          "password":"1234"
        }
==================================================
`);
});

app.post("/login", (req, res) => {
  console.log(req.body);
  const username = req.body.username;
  const password = req.body.password;
  const sql = "SELECT * FROM users WHERE username = ? AND password = ? ";
  db.query(sql, [username, password], (err, result) => {
    if (err) {
      return res.status(500).json({
        message: "Database Error",
      });
    }
    if (result.length > 0) {
      res.json({
        status: true,
        message: "Login Success",
      });
    } else {
      res.json({
        status: false,
        message: "Username หรือ Password ไม่ถูกต้อง",
      });
    }
  });
});

app.get('/api/users',(req,res)=>{
    const sql = 'SELECT * FROM users';
    db.query(sql,(err,result)=>{
        if(err){
            return res.status(500).json({
                success:false,
                message:'Database Error'
            });
        }
        res.status(200).json({
            success:true,
            data:result
        });
    });
});

app.get('/api/users/:id',(req,res)=>{
    const id = req.params.id;
    db.query('SELECT * FROM users WHERE id=?',[id],(err,result)=>{
            if(result.length===0){
                return res.status(404).json({
                    success:false,
                    message:'User Not Found'
                });
            }
            res.status(200).json({
                success:true,
                data:result[0]
            });
        }
    );
});

app.post('/api/users',(req,res)=>{
    const {
        username,
        fullname,
        email
    } = req.body;
    const sql=`INSERT INTO users (username,fullname,email) VALUES(?,?,?)`;
    db.query(sql,[username,fullname,email],(err,result)=>{
            if(err){

                return res.status(500).json({
                    success:false
                });
            }
            res.status(201).json({
                success:true,
                message:'User Created',
                id:result.insertId
            });
        }
    );
});

app.put('/api/users/:id',(req,res)=>{
    const id=req.params.id;
    const {username,fullname,email} = req.body;
    db.query(`UPDATE users SET username=?, fullname=?, email=? WHERE id=?`,[username,fullname,email,id],(err,result)=>{

            if(result.affectedRows===0){
                return res.status(404).json({
                    success:false,
                    message:'User Not Found'
                });
            }
            res.status(200).json({
                success:true,
                message:'Updated'
            });
        }
    );

});

